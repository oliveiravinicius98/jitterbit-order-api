# Jitterbit Order API

API em Node.js com JavaScript para gerenciar pedidos, desenvolvida para o desafio técnico da Jitterbit.

## Tecnologias

- Node.js
- Express
- MongoDB
- Mongoose

## Funcionalidades

- Criar pedido
- Buscar pedido por `orderId`
- Listar pedidos
- Atualizar pedido
- Excluir pedido
- Mapping do payload de entrada para o formato salvo no banco
- Tratamento de erros com respostas HTTP adequadas

## Estrutura do projeto

```bash
src/
  app.js
  server.js
  config/
    database.js
  controllers/
    order.controller.js
  middlewares/
    error.middleware.js
  models/
    order.model.js
  routes/
    order.routes.js
```

## Instalação

```bash
npm install
```

## Configuração

Crie um arquivo `.env` com base no `.env.example`:

```env
PORT=3000
MONGODB_URI=mongodb://127.0.0.1:27017/jitterbit_orders
```

## Executar projeto

Modo desenvolvimento:

```bash
npm run dev
```

Modo normal:

```bash
npm start
```

## Endpoints

### Health check

```http
GET /
```

### Criar pedido

```http
POST /order
```

Body de entrada:

```json
{
  "numeroPedido": "v10089015vdb-01",
  "valorTotal": 10000,
  "dataCriacao": "2023-07-19T12:24:11.5299601+00:00",
  "items": [
    {
      "idItem": "2434",
      "quantidadeItem": 1,
      "valorItem": 1000
    }
  ]
}
```

Payload salvo:

```json
{
  "orderId": "v10089015vdb-01",
  "value": 10000,
  "creationDate": "2023-07-19T12:24:11.529Z",
  "items": [
    {
      "productId": 2434,
      "quantity": 1,
      "price": 1000
    }
  ]
}
```

### Buscar pedido

```http
GET /order/:orderId
```

### Listar pedidos

```http
GET /order/list
```

### Atualizar pedido

```http
PUT /order/:orderId
```

### Excluir pedido

```http
DELETE /order/:orderId
```

## Exemplo cURL

### Criar pedido

```bash
curl --location 'http://localhost:3000/order' \
--header 'Content-Type: application/json' \
--data '{
  "numeroPedido": "v10089015vdb-01",
  "valorTotal": 10000,
  "dataCriacao": "2023-07-19T12:24:11.5299601+00:00",
  "items": [
    {
      "idItem": "2434",
      "quantidadeItem": 1,
      "valorItem": 1000
    }
  ]
}'
```

## Respostas HTTP usadas

- `200 OK`
- `201 Created`
- `400 Bad Request`
- `404 Not Found`
- `409 Conflict`
- `500 Internal Server Error`

## Melhorias opcionais futuras

- Autenticação com JWT
- Swagger
- Testes automatizados
- Docker

## GitHub

Depois de criar o repositório:

```bash
git init
git add .
git commit -m "feat: initial Jitterbit order API"
git branch -M main
git remote add origin <URL_DO_REPOSITORIO>
git push -u origin main
```
