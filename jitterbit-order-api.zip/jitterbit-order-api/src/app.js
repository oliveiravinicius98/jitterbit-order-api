const express = require('express');
const orderRoutes = require('./routes/order.routes');
const { notFoundHandler, errorHandler } = require('./middlewares/error.middleware');

const app = express();

app.use(express.json());

app.get('/', (req, res) => {
  return res.status(200).json({
    message: 'Jitterbit Order API is running.'
  });
});

app.use('/', orderRoutes);
app.use(notFoundHandler);
app.use(errorHandler);

module.exports = app;
