function notFoundHandler(req, res) {
  return res.status(404).json({
    message: 'Route not found.'
  });
}

function errorHandler(error, req, res, next) {
  console.error(error);

  if (error.name === 'ValidationError') {
    return res.status(400).json({
      message: 'Validation error.',
      details: Object.values(error.errors).map((item) => item.message)
    });
  }

  if (error.code === 11000) {
    return res.status(409).json({
      message: 'An order with this orderId already exists.'
    });
  }

  return res.status(500).json({
    message: 'Internal server error.'
  });
}

module.exports = { notFoundHandler, errorHandler };
