const Order = require('../models/order.model');

function mapIncomingOrder(payload) {
  return {
    orderId: String(payload.numeroPedido).trim(),
    value: Number(payload.valorTotal),
    creationDate: new Date(payload.dataCriacao),
    items: Array.isArray(payload.items)
      ? payload.items.map((item) => ({
          productId: Number(item.idItem),
          quantity: Number(item.quantidadeItem),
          price: Number(item.valorItem)
        }))
      : []
  };
}

function mapOutgoingOrder(order) {
  return {
    orderId: order.orderId,
    value: order.value,
    creationDate: order.creationDate,
    items: order.items
  };
}

function validateIncomingPayload(body) {
  if (!body || typeof body !== 'object') {
    return 'Request body is required.';
  }

  if (!body.numeroPedido) {
    return 'Field "numeroPedido" is required.';
  }

  if (body.valorTotal === undefined || body.valorTotal === null) {
    return 'Field "valorTotal" is required.';
  }

  if (!body.dataCriacao) {
    return 'Field "dataCriacao" is required.';
  }

  if (!Array.isArray(body.items)) {
    return 'Field "items" must be an array.';
  }

  for (const item of body.items) {
    if (!item.idItem || item.quantidadeItem === undefined || item.valorItem === undefined) {
      return 'Each item must contain "idItem", "quantidadeItem" and "valorItem".';
    }
  }

  return null;
}

async function createOrder(req, res, next) {
  try {
    const validationError = validateIncomingPayload(req.body);

    if (validationError) {
      return res.status(400).json({ message: validationError });
    }

    const mappedOrder = mapIncomingOrder(req.body);
    const createdOrder = await Order.create(mappedOrder);

    return res.status(201).json({
      message: 'Order created successfully.',
      data: mapOutgoingOrder(createdOrder)
    });
  } catch (error) {
    return next(error);
  }
}

async function getOrderById(req, res, next) {
  try {
    const { orderId } = req.params;
    const order = await Order.findOne({ orderId });

    if (!order) {
      return res.status(404).json({
        message: 'Order not found.'
      });
    }

    return res.status(200).json({ data: mapOutgoingOrder(order) });
  } catch (error) {
    return next(error);
  }
}

async function listOrders(req, res, next) {
  try {
    const orders = await Order.find().sort({ createdAt: -1 });

    return res.status(200).json({
      total: orders.length,
      data: orders.map(mapOutgoingOrder)
    });
  } catch (error) {
    return next(error);
  }
}

async function updateOrder(req, res, next) {
  try {
    const { orderId } = req.params;
    const validationError = validateIncomingPayload(req.body);

    if (validationError) {
      return res.status(400).json({ message: validationError });
    }

    const mappedOrder = mapIncomingOrder(req.body);
    mappedOrder.orderId = orderId;

    const updatedOrder = await Order.findOneAndUpdate(
      { orderId },
      mappedOrder,
      { new: true, runValidators: true }
    );

    if (!updatedOrder) {
      return res.status(404).json({
        message: 'Order not found.'
      });
    }

    return res.status(200).json({
      message: 'Order updated successfully.',
      data: mapOutgoingOrder(updatedOrder)
    });
  } catch (error) {
    return next(error);
  }
}

async function deleteOrder(req, res, next) {
  try {
    const { orderId } = req.params;
    const deletedOrder = await Order.findOneAndDelete({ orderId });

    if (!deletedOrder) {
      return res.status(404).json({
        message: 'Order not found.'
      });
    }

    return res.status(200).json({
      message: 'Order deleted successfully.'
    });
  } catch (error) {
    return next(error);
  }
}

module.exports = {
  createOrder,
  getOrderById,
  listOrders,
  updateOrder,
  deleteOrder,
  mapIncomingOrder
};
